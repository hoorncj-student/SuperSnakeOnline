package edu.rosehulman.supersnakeonline;


public enum PowerupType {
	SLOWER, APPLES, SHRINK, FASTER;
}
