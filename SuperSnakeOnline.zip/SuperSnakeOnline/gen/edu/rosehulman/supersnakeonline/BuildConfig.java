/** Automatically generated file. DO NOT MODIFY */
package edu.rosehulman.supersnakeonline;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}